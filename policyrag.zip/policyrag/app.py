"""
PolicyPal - General Insurance Q&A Chatbot (RAG): vehicle, health, home
Single-file project: backend (Flask + TF-IDF retriever + answer generator) and frontend (HTML/CSS/JS).

Run:  pip install -r requirements.txt  ->  python app.py  ->  http://127.0.0.1:5000
Optional: set ANTHROPIC_API_KEY (and pip install anthropic) for LLM-written answers.
Without a key, the app uses a built-in extractive generator, so it works fully offline.
"""
import os, re, math, datetime as dt
from collections import Counter
from flask import Flask, request, jsonify, Response

app = Flask(__name__)

# ----------------------------------------------------------------------------
# 1. KNOWLEDGE BASE  (sample public-style policy: replace/extend via Upload)
# ----------------------------------------------------------------------------
POLICY = "SecureLife Health Shield"
HEALTH = [
    ("Coverage", "Hospitalisation", "The policy covers in-patient hospitalisation expenses for a stay of more than 24 hours, including room rent, nursing, doctor fees, medicines, diagnostics and ICU charges, up to the Sum Insured."),
    ("Coverage", "Day care procedures", "Day care procedures such as dialysis, chemotherapy, cataract surgery and lithotripsy are covered even if hospitalisation is less than 24 hours."),
    ("Coverage", "Ambulance cover", "Road ambulance charges are reimbursed up to Rs 3,000 per hospitalisation when used to transfer the insured to a hospital in an emergency."),
    ("Coverage", "AYUSH treatment", "In-patient treatment under Ayurveda, Yoga, Unani, Siddha and Homeopathy is covered up to the Sum Insured at a government-recognised AYUSH hospital."),
    ("Coverage", "Room rent limit", "Room rent is capped at 1% of the Sum Insured per day and ICU charges at 2% of the Sum Insured per day. Higher room categories lead to proportionate deduction of other expenses."),
    ("Waiting periods", "Initial waiting period", "A 30-day initial waiting period applies from the policy start date. Claims arising in this period are not payable, except those caused by an accident."),
    ("Waiting periods", "Pre-existing diseases", "Pre-existing diseases such as diabetes, hypertension or heart conditions are covered only after 36 months of continuous coverage with the insurer."),
    ("Waiting periods", "Specific illness waiting period", "Specific illnesses including cataract, hernia, joint replacement, kidney stones and piles have a waiting period of 24 months from the policy start date."),
    ("Waiting periods", "Maternity", "Maternity and newborn expenses are covered after a waiting period of 24 months, with a limit of Rs 50,000 for normal delivery and Rs 75,000 for caesarean delivery."),
    ("Exclusions", "General exclusions", "The policy does not cover cosmetic or plastic surgery unless needed after an accident, dental treatment unless due to accident, infertility treatment, obesity surgery, self-inflicted injury, war, and injuries from adventure sports."),
    ("Exclusions", "Non-medical items", "Non-medical items such as gloves, masks, registration fees, and administrative charges are not payable under the policy."),
    ("Claims", "Cashless claims", "For cashless treatment at a network hospital, intimate the insurer at least 48 hours before a planned admission, or within 24 hours of an emergency admission."),
    ("Claims", "Reimbursement claims", "For reimbursement, submit the claim form, original hospital bills, discharge summary, prescriptions and diagnostic reports within 30 days of discharge."),
    ("Claims", "Claim settlement time", "The insurer will settle or reject a claim within 30 days of receiving all required documents. Delays beyond this attract interest at 2% above the bank rate."),
    ("Premium and renewal", "Co-payment", "A co-payment of 10% applies to every claim for insured persons aged 60 years and above. The insured bears this share of the admissible claim amount."),
    ("Premium and renewal", "Grace period and renewal", "A grace period of 30 days is allowed for renewal. Coverage is not available during the grace period and waiting periods are reset if the policy lapses beyond it."),
    ("Premium and renewal", "Free look period", "You may cancel the policy within 15 days of receiving it (free look period). The premium is refunded after deducting stamp duty and any medical examination costs."),
]
V = lambda sec, t, x: ("vehicle", sec, t, x)
KB_NEW = [
 V("Motor basics", "Types of motor cover", "Motor insurance comes in three forms: Third-Party Only (legally mandatory), Package or Comprehensive (third-party plus own damage) and Standalone Own Damage (for owners who already hold a valid long-term third-party policy)."),
 V("Motor basics", "Third-party liability", "Under the Motor Vehicles Act 1988 every vehicle on a public road needs at least third-party cover. It pays for death or injury to a third party (unlimited liability) and damage to third-party property up to Rs 7.5 lakh."),
 V("Motor basics", "Long-term third-party cover", "A new private car must have a 3-year third-party cover and a new two-wheeler a 5-year third-party cover at purchase. Own damage cover is usually renewed every year."),
 V("Motor basics", "Insured Declared Value (IDV)", "IDV is the maximum amount payable on total loss or theft. It is the manufacturer's listed price minus depreciation: about 5% up to 6 months, 15% up to 1 year, 20% up to 2 years, 30% up to 3 years, 40% up to 4 years and 50% up to 5 years. Older vehicles are agreed with the insurer."),
 V("Motor basics", "No Claim Bonus (NCB)", "NCB is a discount on the own damage premium for every claim-free year: 20% after year one, then 25%, 35%, 45% and 50% after five years. It belongs to the owner, not the vehicle, and is lost when you make an own damage claim unless you buy NCB Protection."),
 V("Motor basics", "Add-on covers", "Popular add-ons are Zero Depreciation (no deduction for parts depreciation, usually for vehicles up to 5 years old), Engine Protect, Return to Invoice, Consumables, Roadside Assistance, Key Replacement, Tyre Protect and NCB Protection."),
 V("Motor basics", "Owner-driver personal accident", "Package policies include a compulsory personal accident cover of Rs 15 lakh for the owner-driver for death or permanent disability. It needs a valid driving licence and can be skipped only if you already hold equivalent cover."),
 V("Motor claims", "Accident claim process", "Inform the insurer immediately, ideally within 24 to 48 hours. File an FIR for theft, third-party injury or death, riot or major damage. Photograph the scene, do not admit liability and do not repair before the surveyor inspects. Submit the claim form, RC, driving licence, policy copy, FIR and repair estimate."),
 V("Motor claims", "Theft and total loss", "For theft, file an FIR and inform the insurer at once. The claim is settled at IDV after the police issue an untraced report and you hand over keys, RC and transfer papers. A repair claim becomes a constructive total loss when repair cost exceeds roughly 75% of IDV."),
 V("Motor claims", "Cashless repair and deductible", "At a network garage the insurer pays the garage directly, except the deductible, depreciation and non-covered items. A compulsory deductible applies (typically Rs 1,000 for private cars up to 1500 cc and Rs 2,000 above; lower for two-wheelers) plus any voluntary deductible you choose."),
 V("Motor exclusions", "Own damage exclusions", "Own damage is not payable for wear and tear, mechanical or electrical breakdown, consequential loss, driving under alcohol or drugs, driving without a valid licence, or use outside the permitted purpose, such as a private car used as a taxi."),
 V("Motor renewal", "Transfer, lapse and renewal", "When a vehicle is sold, the policy should be transferred to the new owner within 14 days. If a policy lapses the vehicle may need inspection, and NCB is lost if the break exceeds 90 days. A valid PUC certificate is needed to renew."),
 ("car", "Car insurance", "Private car cover", "A private car policy covers accidental damage, fire, explosion, theft, natural calamities such as flood, earthquake and cyclone, riot, malicious damage and transit by road or rail. A private car cannot be used for hire; commercial use can void a claim."),
 ("car", "Car insurance", "Accessories and CNG kit", "Non-factory electrical or non-electrical accessories and externally fitted CNG or LPG kits must be declared and added to the IDV. Undeclared items can reduce or reject the claim."),
 ("car", "Car insurance", "Flood and engine damage", "Water entering the engine (hydrostatic lock) is paid only if you have the Engine Protect add-on, and never when the engine was started after submersion."),
 ("car", "Car insurance", "Electric car cover", "Electric cars and bikes can be insured for battery, charger and charging cable. Battery cover often needs an add-on, and EVs usually get lower premium rates."),
 ("bike", "Two-wheeler insurance", "Two-wheeler cover", "A two-wheeler policy covers bikes, scooters and mopeds against accident, fire, theft and natural calamities. Third-party cover is mandatory and new bikes need a 5-year third-party policy."),
 ("bike", "Two-wheeler insurance", "Pillion rider and rider cover", "The owner-rider gets Rs 15 lakh personal accident cover. Pillion rider cover is an optional add-on. Claims are rejected if the rider had no valid licence or was under the influence of alcohol."),
 ("bike", "Two-wheeler insurance", "Bike add-ons and theft", "Useful bike add-ons are Zero Depreciation, Engine Protect, Return to Invoice, Roadside Assistance and Consumables. Theft is the commonest bike claim, so keep both keys and the RC safe."),
 ("auto", "Auto, taxi and bus", "Auto rickshaw and e-rickshaw", "Three-wheelers, including auto rickshaws and e-rickshaws, are rated separately as passenger-carrying or goods-carrying. The package covers own damage, third-party liability, owner-driver personal accident and legal liability to the paid driver."),
 ("auto", "Auto, taxi and bus", "Passenger liability", "Hired passenger vehicles are covered for legal liability to passengers. Personal accident cover for passengers, as per seating capacity, is an add-on. Carrying more passengers than the permitted seating capacity is a violation."),
 ("auto", "Auto, taxi and bus", "Taxi, cab and bus", "Premium for taxis, cabs and buses depends on seating capacity, cc, age and zone. A valid permit, fitness certificate and licence with badge are required, and permit breaches can lead to claim rejection."),
 ("truck", "Truck and lorry", "Goods-carrying vehicle policy", "Trucks, lorries, trailers and tippers are insured under a commercial vehicle package covering own damage, third-party liability, owner-driver personal accident and legal liability to the driver and cleaner. Fleet policies are available for several vehicles."),
 ("truck", "Truck and lorry", "Overloading", "Carrying goods above the registered carrying capacity (GVW) violates the policy. The insurer may pay only a reduced share, often around 75%, or reject own damage claims, but third-party victims are still compensated."),
 ("truck", "Truck and lorry", "Valid documents for claims", "At the time of an accident the fitness certificate, permit, registration and a driving licence for that vehicle class must be valid. Expired documents can lead to rejection of the own damage claim."),
 ("truck", "Truck and lorry", "Goods in transit", "The motor policy does not cover the cargo. Loss or damage to goods needs a separate Marine Inland Transit or goods-in-transit policy."),
 ("mini", "Tata Ace and mini carriers", "Small goods carriers", "Tata Ace, Mahindra Jeeto, Chhota Hathi, pickups and other mini trucks are insured as light goods-carrying vehicles. Premium depends on GVW or carrying capacity, age, location zone and IDV."),
 ("mini", "Tata Ace and mini carriers", "Mini carrier package cover", "A mini carrier package covers own damage, third-party liability, owner-driver personal accident and legal liability to a paid driver or cleaner. Use must match the registered purpose and permit, and carrying passengers in a goods carrier can void a claim."),
 ("mini", "Tata Ace and mini carriers", "Last-mile delivery use", "Mini carriers used for last-mile delivery make many short trips, so accident and theft risk is higher. Zero Depreciation and Roadside Assistance are recommended, and electric mini carriers need battery cover."),
 ("equip", "JCB and construction equipment", "JCB and equipment cover", "JCB backhoe loaders, excavators, cranes, loaders and rollers are insured as Miscellaneous and Special Type vehicles when they run on public roads, and under Contractor's Plant and Machinery (CPM) insurance when working on a site."),
 ("equip", "JCB and construction equipment", "CPM cover and exclusions", "CPM covers accidental damage, fire, theft, flood, overturning and collapse. Normal wear and tear, mechanical or electrical breakdown without external cause, and damage by an unlicensed operator are excluded."),
 ("equip", "JCB and construction equipment", "JCB third-party liability", "Third-party cover is mandatory if equipment travels on public roads. Injury to site workers is handled under employer's liability or workmen's compensation cover, not the machinery policy."),
 ("equip", "JCB and construction equipment", "JCB premium and documents", "Premium depends on equipment type, make, age, IDV and usage. Keep the purchase invoice, service history, operator licence and site details. Moving equipment on trailers needs transit cover."),
 ("health", "Health basics", "Moratorium period", "After 60 continuous months of cover, the insurer cannot reject a claim for non-disclosure, except for proven fraud."),
 ("health", "Health basics", "Portability", "You can port your health policy to another insurer at renewal, applying 45 to 60 days before expiry, and keep credit for waiting periods already served."),
 ("health", "Health basics", "Pre and post hospitalisation", "Medical expenses incurred 30 days before admission and 60 days after discharge are covered when linked to the same illness."),
 ("health", "Health basics", "Cumulative bonus and restoration", "Cumulative bonus raises your sum insured for each claim-free year, and the restore benefit refills the sum insured once it is exhausted. Percentages differ by plan."),
 ("health", "Health basics", "Family floater and top-up", "A family floater shares one sum insured among all members. Top-up and super top-up plans add cover above a deductible at a lower premium."),
 ("home", "Home insurance", "What home insurance covers", "Home insurance, such as Bharat Griha Raksha, covers the building and household contents against fire, lightning, explosion, storm, flood, earthquake, landslide, riot, strike, impact damage and burst pipes."),
 ("home", "Home insurance", "Burglary and theft", "Burglary and theft of contents are covered when there is forcible or violent entry, and an FIR is needed. Jewellery, cash and valuables have sub-limits and may need to be listed separately."),
 ("home", "Home insurance", "Valuation and underinsurance", "The building is insured at reinstatement (rebuild) cost, excluding land value. Contents are valued at replacement or market value. If you are underinsured, the average clause reduces the claim proportionately."),
 ("home", "Home insurance", "Home exclusions", "Not covered: wear and tear, gradual damage, war, nuclear risk, wilful acts, electrical breakdown without fire, and losses in homes left unoccupied beyond the allowed period."),
 ("home", "Home insurance", "Tenants and add-ons", "Tenants can insure household contents while owners insure the structure. Add-ons include alternative accommodation, loss of rent, public liability, personal accident and electronics cover."),
 ("home", "Home insurance", "Home claim process", "Inform the insurer immediately and secure the property. File an FIR for theft or riot and get a fire brigade report for fire. A surveyor inspects; submit photos and invoices. Settlement is due within 30 days of the final document."),
 ("general", "General rules", "Surveyor and settlement timelines", "The insurer normally appoints a surveyor within 24 hours of intimation, the survey report is due in 15 days, and the claim must be settled within 30 days of the last required document."),
 ("general", "General rules", "Disclosure and fraud", "Give correct details about the vehicle, property, past claims and health history. Misrepresentation or fraud can lead to claim rejection or cancellation of the policy."),
 ("general", "General rules", "Grievance redressal", "Complain first to the insurer's grievance officer. If unresolved in 15 days, escalate through the IRDAI Bima Bharosa portal or the Insurance Ombudsman, which is free and handles claims up to Rs 30 lakh."),
 ("general", "General rules", "Read your policy schedule", "Check the policy schedule for IDV or sum insured, deductibles, add-ons, exclusions and expiry date. The policy wording always overrides general guidance."),
]

CLAUSES = [("health",)+t for t in HEALTH] + KB_NEW
USER_CLAUSES = []  # added via upload

STOP = set("a an the is are was be to of in on for and or if do does can i my me it its this that what how when which who with by at from as will would should any there their about get have has under policy cover covered covers".split())

def tokens(text):
    out = []
    for w in re.findall(r"[a-z0-9]+", text.lower()):
        if w in STOP or len(w) < 2:
            continue
        for suf in ("ing", "ed", "es", "s"):
            if w.endswith(suf) and len(w) - len(suf) >= 4:
                w = w[: -len(suf)]
                break
        out.append(w)
    return out

CHUNKS, IDF = [], {}

def build_index():
    """Create chunks and TF-IDF vectors (the 'retrieval' half of RAG)."""
    global CHUNKS, IDF
    CHUNKS = []
    for i, (cat, sec, title, text) in enumerate(CLAUSES + USER_CLAUSES, 1):
        tf = Counter(tokens(sec + " " + title + " " + title + " " + text))  # title counts double
        CHUNKS.append({"id": i, "cat": cat, "section": sec, "title": title, "text": text, "tf": tf})
    df = Counter(t for c in CHUNKS for t in c["tf"])
    n = len(CHUNKS)
    IDF = {t: math.log((n + 1) / (d + 0.5)) + 1 for t, d in df.items()}
    for c in CHUNKS:
        vec = {t: f * IDF[t] for t, f in c["tf"].items()}
        norm = math.sqrt(sum(v * v for v in vec.values())) or 1
        c["vec"] = {t: v / norm for t, v in vec.items()}

VEH = {"car", "bike", "auto", "truck", "mini", "equip"}
KW = {
    "car": r"\b(cars?|sedan|suv|hatchback|four[- ]?wheeler)\b",
    "bike": r"\b(bikes?|scooters?|motorcycles?|moped|two[- ]?wheeler|2[- ]?wheeler)\b",
    "auto": r"\b(autos?|rickshaws?|e-?rickshaws?|three[- ]?wheeler|taxi|cab|bus)\b",
    "truck": r"\b(trucks?|lorry|lorries|trailer|tipper|goods carrier)\b",
    "mini": r"\b(tata ace|ace|chhota hathi|mini truck|pickup|pick-up|mini carrier|jeeto)\b",
    "equip": r"\b(jcb|excavator|backhoe|crane|loader|bulldozer|roller|earthmover|construction equipment|tractor)\b",
    "health": r"\b(health|hospital\w*|cashless|mediclaim|maternity|surgery|cataract|diabetes)\b",
    "home": r"\b(home|house|flat|apartment|burglary|household)\b",
}
def detect(q):
    q = q.lower()
    return next((c for c, p in KW.items() if re.search(p, q)), None)

def applies(ccat, sel):
    return ccat == sel or ccat == "general" or (ccat == "vehicle" and sel in VEH)

def retrieve(query, k=3, cat="all"):
    q = Counter(tokens(query))
    qv = {t: f * IDF[t] for t, f in q.items() if t in IDF}
    norm = math.sqrt(sum(v * v for v in qv.values()))
    explicit = cat if cat in KW else None
    det = explicit or detect(query)
    if not qv:
        return [], 0, det
    scored = []
    for c in CHUNKS:
        if explicit and not applies(c["cat"], explicit):
            continue
        s = sum(w * c["vec"].get(t, 0) for t, w in qv.items()) / norm
        cov = sum(w for t, w in qv.items() if t in c["tf"]) / sum(qv.values())
        s *= cov ** 2
        if det and not explicit:  # soft routing from words in the question
            if c["cat"] == det:
                s *= 1.3
            elif not applies(c["cat"], det):
                s *= 0.7
        if s > 0:
            scored.append((s, c))
    scored.sort(key=lambda x: -x[0])
    return scored[:k], len(qv), det

# ----------------------------------------------------------------------------
# 2. GENERATION  (LLM if key present, else extractive)
# ----------------------------------------------------------------------------
def generate(question, hits):
    key = os.getenv("ANTHROPIC_API_KEY")
    if key:
        try:
            import anthropic
            ctx = "\n".join(f"[{i}] {c['title']}: {c['text']}" for i, (_, c) in enumerate(hits, 1))
            msg = anthropic.Anthropic(api_key=key).messages.create(
                model="claude-sonnet-4-6", max_tokens=500,
                system="You are an insurance policy assistant. Answer ONLY from the numbered clauses. Cite clauses like [1]. If the clauses do not answer the question, say so. Be clear and brief.",
                messages=[{"role": "user", "content": f"Clauses:\n{ctx}\n\nQuestion: {question}"}])
            return msg.content[0].text, "LLM"
        except Exception as e:
            print("LLM fallback:", e)
    top = hits[0][0]
    parts = [f"**{c['title']}** [{i}]: {c['text']}" for i, (s, c) in enumerate(hits, 1) if s >= 0.6 * top][:2]
    return "Here is what the policy says:\n\n" + "\n\n".join(parts), "Extractive"

# ----------------------------------------------------------------------------
# 3. CONFIDENCE + HUMAN REVIEW QUEUE
# ----------------------------------------------------------------------------
LOG, REVIEW = [], []

def seed():
    today = dt.date.today()
    for d, (a, f) in enumerate([(22, 6), (14, 4), (18, 5), (30, 9), (12, 5), (20, 4), (26, 7)]):
        day = today - dt.timedelta(days=6 - d)
        LOG.extend([{"day": day, "flag": False, "conf": .8}] * a + [{"day": day, "flag": True, "conf": .3}] * f)

def assess(hits, nq):
    if not hits:
        return 0.0, "No matching clause found"
    top = hits[0][0]
    conf = min(1.0, top / 0.4)
    reason = None
    if conf < 0.45:
        reason = "Low confidence: weak match with policy text"
    elif len(hits) > 1 and hits[0][0] - hits[1][0] < 0.02 and hits[0][1]["section"] != hits[1][1]["section"] and nq <= 2:
        reason = "Ambiguous: question matches several sections equally"
    return round(conf, 2), reason

@app.post("/api/chat")
def chat():
    q = (request.json or {}).get("question", "").strip()
    if not q:
        return jsonify(error="Type a question first."), 400
    cat = (request.json or {}).get("category", "all")
    hits, nq, det = retrieve(q, cat=cat)
    conf, reason = assess(hits, nq)
    if not hits:
        answer, mode = "I could not find this in the policy documents. I have sent your question to a human advisor.", "None"
    else:
        answer, mode = generate(q, hits)
        if reason:
            answer += "\n\n_This answer needs a human check before you rely on it._"
    if reason:
        REVIEW.insert(0, {"id": len(REVIEW) + 1, "q": q, "conf": conf, "reason": reason, "time": dt.datetime.now().strftime("%d %b, %H:%M")})
    LOG.append({"day": dt.date.today(), "flag": bool(reason), "conf": conf})
    return jsonify(answer=answer, mode=mode, category=det, confidence=conf, flagged=bool(reason), reason=reason,
                   sources=[{"n": i, "cat": c["cat"], "section": c["section"], "title": c["title"], "text": c["text"], "score": round(s, 2)} for i, (s, c) in enumerate(hits, 1)])

@app.get("/api/stats")
def stats():
    today = dt.date.today()
    days = []
    for d in range(6, -1, -1):
        day = today - dt.timedelta(days=d)
        rows = [r for r in LOG if r["day"] == day]
        fl = sum(r["flag"] for r in rows)
        days.append({"label": day.strftime("%a"), "answered": len(rows) - fl, "flagged": fl})
    avg = sum(r["conf"] for r in LOG) / max(1, len(LOG))
    return jsonify(days=days, total=len(LOG), avg=round(avg * 100), review=len(REVIEW), clauses=len(CHUNKS))

@app.get("/api/docs")
def docs():
    return jsonify([{"id": c["id"], "cat": c["cat"], "section": c["section"], "title": c["title"], "text": c["text"]} for c in CHUNKS])

@app.get("/api/review")
def review():
    return jsonify(REVIEW)

@app.post("/api/upload")
def upload():
    f = request.files.get("file")
    if not f or not f.filename.lower().endswith(".txt"):
        return jsonify(error="Upload a .txt policy file (clauses separated by blank lines)."), 400
    raw = f.read().decode("utf-8", "ignore")
    added = 0
    for para in re.split(r"\n\s*\n", raw):
        para = " ".join(para.split())
        if len(para) > 40:
            USER_CLAUSES.append((request.form.get("cat", "general"), f.filename, para[:60] + "...", para))
            added += 1
    build_index()
    return jsonify(added=added)

# ----------------------------------------------------------------------------
# 4. FRONTEND  (theme: white cards, teal + coral accents, rounded sidebar)
# ----------------------------------------------------------------------------
PAGE = r"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>PolicyPal - General Insurance Q&A</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{--teal:#12a5a8;--teal-s:#d9eff0;--coral:#f47b5e;--coral-s:#fcd6cb;--ink:#2a2e3a;--mute:#8a90a0;--line:#eceef3;--bg:#fff;--page:#7fd1db}
*{box-sizing:border-box}body{margin:0;font-family:Poppins,system-ui,sans-serif;background:var(--page);color:var(--ink);padding:14px;min-height:100vh}
.app{display:grid;grid-template-columns:230px 1fr 340px;gap:0;background:#f6f8fb;border-radius:16px;overflow:hidden;min-height:calc(100vh - 28px)}
aside{background:#fff;padding:22px 16px;display:flex;flex-direction:column;gap:6px;border-right:1px solid var(--line)}
.logo{font-weight:700;font-size:22px;color:var(--teal);margin:0 8px 18px}.logo b{color:var(--coral)}
nav button{all:unset;display:flex;gap:10px;align-items:center;padding:11px 16px;border-radius:22px;font-size:14px;color:#4a5060;cursor:pointer;width:calc(100% - 32px)}
nav button:hover{background:#f1f5f7}nav button.on{background:var(--teal-s);color:var(--teal);font-weight:600}
nav button:focus-visible,.btn:focus-visible,input:focus-visible{outline:2px solid var(--teal);outline-offset:2px}
.badge{margin-left:auto;background:var(--coral);color:#fff;font-size:11px;border-radius:10px;padding:1px 7px}
.cta{margin-top:12px;background:var(--teal);color:#fff;border-radius:22px;padding:11px;text-align:center;font-size:14px;cursor:pointer;border:0;font-family:inherit}
.user{margin-top:auto;display:flex;gap:10px;align-items:center;padding:10px;border-top:1px solid var(--line);font-size:13px}
.av{width:34px;height:34px;border-radius:50%;background:var(--coral-s);display:grid;place-items:center;font-weight:600;color:var(--coral)}
main{padding:22px 24px;display:flex;flex-direction:column;gap:18px;overflow:auto;max-height:calc(100vh - 28px)}
.card{background:#fff;border:1px solid var(--line);border-radius:14px;padding:18px}
h1{font-size:20px;margin:0 0 4px}h2{font-size:15px;margin:0 0 12px}p.s{margin:0;color:var(--mute);font-size:13px}
.view{display:none;flex-direction:column;gap:18px}.view.on{display:flex}
.hero{display:flex;justify-content:space-between;align-items:center;gap:12px}
.pill{display:inline-block;border:1px solid var(--coral);color:var(--coral);border-radius:16px;padding:5px 14px;font-size:12px;margin-top:10px}
.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.kpi{background:#fff;border:1px solid var(--line);border-radius:14px;padding:14px}
.kpi b{font-size:24px;display:block}.kpi span{font-size:12px;color:var(--mute)}
.chart{display:flex;align-items:flex-end;gap:16px;height:170px;padding:6px 4px;border-bottom:1px solid var(--line)}
.col{flex:1;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;height:100%;gap:0}
.bar{width:100%;max-width:26px}.bar.a{background:var(--teal);border-radius:0 0 4px 4px}.bar.f{background:var(--coral);border-radius:4px 4px 0 0}
.lbls{display:flex;gap:16px;padding:6px 4px;font-size:11px;color:var(--mute)}.lbls span{flex:1;text-align:center}
.leg{display:flex;gap:16px;font-size:12px;color:var(--mute);margin-bottom:8px}.dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:5px}
.chat{flex:1;display:flex;flex-direction:column;min-height:420px}.msgs{flex:1;overflow:auto;display:flex;flex-direction:column;gap:12px;padding-bottom:10px}
.m{max-width:82%;padding:12px 15px;border-radius:14px;font-size:14px;line-height:1.55;white-space:pre-wrap}
.m.u{align-self:flex-end;background:var(--teal);color:#fff;border-bottom-right-radius:4px}.m.b{background:#fff;border:1px solid var(--line);border-bottom-left-radius:4px}
.m.flag{background:var(--coral-s);border-color:var(--coral-s)}
.src{margin-top:10px;display:flex;flex-direction:column;gap:6px}.src details{background:#f6f8fb;border-radius:8px;padding:6px 10px;font-size:12px}.src summary{cursor:pointer;color:var(--teal);font-weight:500}
.meter{height:6px;background:var(--line);border-radius:4px;margin-top:10px;overflow:hidden}.meter i{display:block;height:100%}
.row{display:flex;gap:8px}.row input{flex:1;border:1px solid var(--line);border-radius:22px;padding:12px 18px;font:inherit;font-size:14px}
.btn{background:var(--teal);color:#fff;border:0;border-radius:22px;padding:0 22px;font:inherit;cursor:pointer}
.chips{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px}.chip{background:var(--teal-s);color:var(--teal);border:0;border-radius:14px;padding:6px 12px;font:inherit;font-size:12px;cursor:pointer}
.right{padding:22px 20px;display:flex;flex-direction:column;gap:14px;background:#fff;border-left:1px solid var(--line);overflow:auto;max-height:calc(100vh - 28px)}
.rv{border-radius:12px;padding:12px;background:var(--coral-s);font-size:13px}.rv small{display:block;color:#7a4a3d;margin-top:4px}
.rv.ok{background:var(--teal-s)}.cl{border-bottom:1px solid var(--line);padding:10px 0;font-size:13px}.cl b{display:block}.cl em{font-style:normal;color:var(--teal);font-size:11px}
.chip.cat.on{background:var(--teal);color:#fff}
@media(max-width:1000px){.app{grid-template-columns:1fr}aside{flex-direction:row;flex-wrap:wrap}.user{display:none}.kpis{grid-template-columns:1fr 1fr}.right,main{max-height:none}}
</style></head><body><div class="app">
<aside><div class="logo">Policy<b>Pal</b></div>
<nav>
<button class="on" data-v="home">Dashboard</button><button data-v="chat">Ask a question</button>
<button data-v="docs">Policy library</button><button data-v="rev">Review queue <span class="badge" id="rb" hidden>0</span></button></nav>
<button class="cta" onclick="show('chat')">Ask about my policy</button>
<div class="user"><div class="av">P</div><div>Policyholder<br><span style="color:var(--mute);font-size:11px" id="pn"></span></div></div></aside>

<main>
<section class="view on" id="v-home">
 <div class="card hero"><div><h1>Welcome back</h1><p class="s">Plain answers on vehicle, health and home insurance: coverage, add-ons, exclusions, waiting periods and claims, each with the clause it came from.</p><span class="pill">Answers are checked for confidence</span></div></div>
 <div class="kpis"><div class="kpi"><b id="k1">0</b><span>Questions answered</span></div><div class="kpi"><b id="k2">0%</b><span>Average confidence</span></div><div class="kpi"><b id="k3">0</b><span>Sent to human review</span></div><div class="kpi"><b id="k4">0</b><span>Clauses indexed</span></div></div>
 <div class="card"><h2>Weekly activity</h2><div class="leg"><span><i class="dot" style="background:var(--coral)"></i>Flagged</span><span><i class="dot" style="background:var(--teal)"></i>Answered</span></div><div class="chart" id="chart"></div><div class="lbls" id="lbls"></div></div>
</section>

<section class="view" id="v-chat" style="flex:1"><div class="card chat">
 <h2>Ask about your policy</h2>
 <div class="chips" id="cats"></div><div class="chips" id="chips"></div>
 <div class="msgs" id="msgs"><div class="m b">Hi! Ask me about car, bike, auto, truck, Tata Ace, JCB, health or home insurance. Pick a category above for sharper answers. I will show the clauses I used.</div></div>
 <div class="row"><input id="q" placeholder="e.g. Is my JCB covered when it works on a site?" autocomplete="off"><button class="btn" id="send">Send</button></div></div></section>

<section class="view" id="v-docs"><div class="card"><h2>Policy library</h2>
 <p class="s" style="margin-bottom:12px">Add your own policy as a .txt file. Separate clauses with a blank line.</p>
 <select id="ucat" style="padding:8px;border-radius:12px;border:1px solid var(--line)"><option value="general">General</option><option value="vehicle">All vehicles</option><option value="car">Car</option><option value="bike">Two-wheeler</option><option value="auto">Auto / taxi</option><option value="truck">Truck</option><option value="mini">Tata Ace type</option><option value="equip">JCB / equipment</option><option value="health">Health</option><option value="home">Home</option></select> <input type="file" id="file" accept=".txt"> <button class="btn" style="padding:8px 18px" onclick="up()">Add to library</button> <span class="s" id="upm"></span>
 <div id="docs" style="margin-top:12px"></div></div></section>

<section class="view" id="v-rev"><div class="card"><h2>Needs a human check</h2><div id="rev"></div></div></section>
</main>

<div class="right"><div class="card" style="padding:14px"><h2>Quick topics</h2><div class="chips" id="topics"></div></div>
 <div class="card" style="padding:14px"><h2>Latest flagged</h2><div id="mini"></div></div></div>
</div>
<script>
const $=s=>document.querySelector(s),esc=t=>t.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
const md=t=>esc(t).replace(/\*\*(.+?)\*\*/g,'<b>$1</b>').replace(/_(.+?)_/g,'<i>$1</i>');
const CATS=[["all","All"],["car","Car"],["bike","Two-wheeler"],["auto","Auto / taxi"],["truck","Truck"],["mini","Tata Ace type"],["equip","JCB / equipment"],["health","Health"],["home","Home"]];
const LBL=Object.fromEntries(CATS);LBL.vehicle='All vehicles';LBL.general='General rules';let CAT='all';
const QS={all:["How does No Claim Bonus work?","What is the waiting period for pre-existing diseases?","What does home insurance cover?"],
car:["What is IDV?","Is engine damage from flood covered?","What does zero depreciation mean?"],
bike:["Is pillion rider covered?","What if my bike is stolen?","Do new bikes need 5-year third-party?"],
auto:["Does auto insurance cover passengers?","What documents do taxis need for a claim?","Is e-rickshaw covered?"],
truck:["What happens if my truck is overloaded?","Are goods in my truck covered?","Which documents must be valid for a claim?"],
mini:["How is a Tata Ace insured?","Can I carry passengers in a mini carrier?","Which add-ons suit delivery use?"],
equip:["Is JCB covered on a construction site?","What is CPM insurance?","Does a JCB need third-party cover on roads?"],
health:["What is the waiting period for pre-existing diseases?","How do I file a cashless claim?","What is the co-payment for seniors?"],
home:["What does home insurance cover?","Is burglary covered?","What is the average clause?"]};
function show(v){document.querySelectorAll('.view').forEach(e=>e.classList.toggle('on',e.id=='v-'+v));document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('on',b.dataset.v==v));
 if(v=='home')stats();if(v=='docs')docs();if(v=='rev'||v=='home')rev()}
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>show(b.dataset.v));
async function stats(){const d=await(await fetch('/api/stats')).json();$('#k1').textContent=d.total;$('#k2').textContent=d.avg+'%';$('#k3').textContent=d.review;$('#k4').textContent=d.clauses;
 const mx=Math.max(...d.days.map(x=>x.answered+x.flagged),1),H=150;
 $('#chart').innerHTML=d.days.map(x=>`<div class="col" title="${x.answered} answered, ${x.flagged} flagged"><div class="bar f" style="height:${x.flagged/mx*H}px"></div><div class="bar a" style="height:${x.answered/mx*H}px"></div></div>`).join('');
 $('#lbls').innerHTML=d.days.map(x=>`<span>${x.label}</span>`).join('');const b=$('#rb');b.hidden=!d.review;b.textContent=d.review}
async function rev(){const r=await(await fetch('/api/review')).json();
 const h=r.length?r.map(x=>`<div class="rv" style="margin-bottom:8px">${esc(x.q)}<small>${x.reason} · confidence ${Math.round(x.conf*100)}% · ${x.time}</small></div>`).join(''):'<div class="rv ok">Nothing waiting. Low-confidence questions will appear here.</div>';
 $('#rev').innerHTML=h;$('#mini').innerHTML=r.length?r.slice(0,3).map(x=>`<div class="rv" style="margin-bottom:8px">${esc(x.q)}</div>`).join(''):'<div class="rv ok">No flagged questions yet.</div>'}
async function docs(){const d=await(await fetch('/api/docs')).json();let last='';$('#docs').innerHTML=d.map(c=>{const h=c.cat!=last?(last=c.cat,`<h2 style="margin-top:16px">${LBL[c.cat]||c.cat}</h2>`):'';return h+`<div class="cl"><em>${esc(c.section)}</em><b>${esc(c.title)}</b>${esc(c.text)}</div>`}).join('')}
async function up(){const f=$('#file').files[0];if(!f)return;const fd=new FormData();fd.append('file',f);fd.append('cat',$('#ucat').value);const r=await fetch('/api/upload',{method:'POST',body:fd}),d=await r.json();
 $('#upm').textContent=r.ok?`Added ${d.added} clauses.`:d.error;docs()}
function add(cls,html){const m=document.createElement('div');m.className='m '+cls;m.innerHTML=html;$('#msgs').appendChild(m);$('#msgs').scrollTop=1e9;return m}
async function ask(t){t=(t||$('#q').value).trim();if(!t)return;show('chat');$('#q').value='';add('u',esc(t));const w=add('b','Searching the policy...');
 const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:t,category:CAT})}),d=await r.json();
 if(!r.ok){w.textContent=d.error;return}
 const pct=Math.round(d.confidence*100),col=pct>=70?'var(--teal)':pct>=45?'#e9b44c':'var(--coral)';
 w.className='m b'+(d.flagged?' flag':'');
 w.innerHTML=md(d.answer)+`<div class="meter"><i style="width:${pct}%;background:${col}"></i></div><div class="s" style="font-size:11px;margin-top:4px">Confidence ${pct}%${d.flagged?' · '+esc(d.reason)+' · sent to review':''} · ${d.mode}${d.category?' · '+LBL[d.category]:''}</div>`
 +(d.sources.length?`<div class="src">${d.sources.map(s=>`<details><summary>[${s.n}] ${esc(s.section)}: ${esc(s.title)} (match ${s.score})</summary>${esc(s.text)}</details>`).join('')}</div>`:'');
 stats();rev()}
$('#send').onclick=()=>ask();$('#q').onkeydown=e=>{if(e.key=='Enter')ask()};
function paint(){$('#cats').innerHTML=CATS.map(([k,l])=>`<button class="chip cat${k==CAT?' on':''}" data-c="${k}">${l}</button>`).join('');
 $('#chips').innerHTML=$('#topics').innerHTML=QS[CAT].map(q=>`<button class="chip q">${q}</button>`).join('');
 document.querySelectorAll('.chip.cat').forEach(c=>c.onclick=()=>{CAT=c.dataset.c;paint()});
 document.querySelectorAll('.chip.q').forEach(c=>c.onclick=()=>ask(c.textContent))}
paint();$('#pn').textContent='All general insurance';stats();rev();
</script></body></html>"""

@app.get("/")
def index():
    return Response(PAGE, mimetype="text/html")

build_index()
seed()

if __name__ == "__main__":
    print("PolicyPal running at http://127.0.0.1:5000")
    app.run(debug=True)
