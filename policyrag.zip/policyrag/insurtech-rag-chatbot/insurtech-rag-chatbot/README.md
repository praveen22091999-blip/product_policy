# PolicyPal - General Insurance Q&A Chatbot (RAG)

Single-file project: everything is in `app.py`.

## Covers
- Vehicles: car, two-wheeler, auto / e-rickshaw / taxi / bus, truck, Tata Ace type mini carriers, JCB and construction equipment
- Health insurance and home insurance
- General rules (claim timelines, grievance, disclosure)

## Run in VS Code
1. File > Open Folder, choose this folder.
2. Terminal: `python -m venv venv`, activate it (Windows: `venv\Scripts\activate`), `pip install -r requirements.txt`, `python app.py`
3. Open http://127.0.0.1:5000

## Optional: LLM answers
`pip install anthropic` and set `ANTHROPIC_API_KEY`. Without it, answers are extracted from the best clauses.

## How it works
- Pick a category chip, or just type: the app detects words like "JCB" or "Tata Ace" and routes to that category.
- Retrieval: TF-IDF over clauses; answers cite their source clauses.
- Low-confidence or ambiguous questions go to the Review queue.
- Add your own policy wording in Policy library (.txt, blank line between clauses, pick a category).

Note: the built-in clauses are general guidance. Your policy wording always overrides them.
